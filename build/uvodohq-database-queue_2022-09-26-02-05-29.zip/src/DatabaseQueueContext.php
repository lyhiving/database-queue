<?php

namespace Uvodo\DatabaseQueue;

use Modules\Plugin\Domain\Context;

/** @package Uvodo\DatabaseQueue */
class DatabaseQueueContext
{
    public static Context $context;
}
